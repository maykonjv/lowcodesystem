import React from 'react'
import Layout from '../components/page/home/Layout'

function Home(props) {
  return <Layout {...props} />
}

export default Home
