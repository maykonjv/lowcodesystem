import React from 'react'
import Head from 'next/head'

import { Container } from '../components/page/login/Background'
import { LoginForm } from '../components/page/login/LoginForm'
import { LoginPanel } from '../components/page/login/LoginPanel'
import { LoginHeader } from '../components/page/login/LoginHeader'

const Login: React.FC = () => {
  return (
    <Container>
      <Head>
        <title>Login</title>
      </Head>

      <LoginPanel>
        <LoginHeader />
        <LoginForm />
      </LoginPanel>
    </Container>
  )
}

export default Login
