import React from 'react'
import Head from 'next/head'

import { Container } from '../components/page/register/Background'
import { RegisterPanel } from '../components/page/register/RegisterPanel'
import { RegisterHeader } from '../components/page/register/RegisterHeader'
import { RegisterForm } from '../components/page/register/RegisterForm'

const Register: React.FC = () => {
  return (
    <Container>
      <Head>
        <title>Register</title>
      </Head>

      <RegisterPanel>
        <RegisterHeader />
        <RegisterForm />
      </RegisterPanel>
    </Container>
  )
}

export default Register
