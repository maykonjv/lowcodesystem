import { useStyletron } from "baseui";

export const LoginForm = () => {
  const [css] = useStyletron();
  
  return (
    <form
      className={css({
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      })}
    >
      <label
        className={css({
          display: "flex",
          alignItems: "left",
          justifyContent: "center",
          marginBottom: "1rem",
          flexDirection: "column",
        })}
      >
        <span
          className={css({
            display: "flex",
            justifyContent: "left",
            marginRight: "0.5rem",
            fontSize: "1rem",
          })}
        >
          Email
        </span>
        <input
          className={css({
            border: "none",
            borderBottom: "1px solid #ccc",
            width: "100%",
            padding: "0.5rem",
            fontSize: "1.5rem",
            "@media (max-width: 768px)": {
              fontSize: "1rem",
            },
          })}
          type="email"
          placeholder="Email"
        />
      </label>
      <label
        className={css({
          display: "flex",
          alignItems: "left",
          justifyContent: "center",
          marginBottom: "1rem",
          flexDirection: "column",
        })}
      >
        <span
          className={css({
            display: "flex",
            justifyContent: "left",
            marginRight: "0.5rem",
            fontSize: "1rem",
          })}
        >
          Password
        </span>
        <input
          className={css({
            border: "none",
            borderBottom: "1px solid #ccc",
            width: "100%",
            padding: "0.5rem",
            fontSize: "1.5rem",
            "@media (max-width: 768px)": {
              fontSize: "1rem",
            },
          })}
          type="password"
          placeholder="Password"
        />
      </label>
      <button
        className={css({
          background: "#00a1ff",
          color: "#fff",
          padding: "0.5rem",
          fontSize: "1.5rem",
          borderRadius: "4px",
          border: "none",
          width: "100%",
          marginTop: "1rem",
          "@media (max-width: 768px)": {
            fontSize: "1rem",
          },
        })}
      >
        Login
      </button>
      {/* Sign up */}
      <div
        className={css({
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginTop: "1rem",
          fontSize: "1rem",
        })}
      >
        Don't have an account?
        <span
          className={css({
            color: "#00a1ff",
            cursor: "pointer",
            ":hover": {
              textDecoration: "underline",
            },
            marginLeft: "0.5rem",
          })}
          onClick={() => {
            console.log("Sign up");
          }}
        >
          Sign up
        </span>
      </div>
    </form>
  );
};
