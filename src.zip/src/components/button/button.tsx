import React from 'react'
import styled from 'styled-components'

interface ButtonProps {
  children: React.ReactNode
  isLoading: boolean
  onPress: (e) => Promise<void>
}

export const Button: React.FC<ButtonProps> = ({
  children,
  isLoading,
  onPress
}) => {
  return (
    <ButtonStyle onClick={onPress} disabled={isLoading}>
      {isLoading ? <Spinner /> : children}
    </ButtonStyle>
  )
}
const ButtonStyle = styled.button`
  width: 100%;
  height: 40px;
  border-radius: ${props => props.theme.radii.medium};
  border: 1px solid ${props => props.theme.colors.primary[1]};
  background-color: ${props => props.theme.colors.primary[1]};
  color: ${props => props.theme.colors.light};
  font-size: ${props => props.theme.fontSizes.medium};
  font-weight: ${props => props.theme.fontWeights.bold};
  cursor: pointer;
  transition: all ${props => props.theme.transitions.small} ease-in-out;
  &:hover {
    background-color: ${props => props.theme.colors.primary[0]};
    border: 1px solid ${props => props.theme.colors.primary[0]};
  }
  &:disabled {
    background-color: ${props => props.theme.colors.primary[1]};
    border: 1px solid ${props => props.theme.colors.primary[1]};
    cursor: not-allowed;
  }
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
`
const Spinner = styled.div`
  width: 20px;
  height: 20px;
  border-radius: 50%;
  border: 2px solid ${props => props.theme.colors.light};
  border-top-color: transparent;
  border-right-color: transparent;
  animation: spin 1s linear infinite;
  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }
    100% {
      transform: rotate(360deg);
    }
  }
`
