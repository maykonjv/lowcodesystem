import React from 'react'
import styled from 'styled-components'

export const LoginHeader: React.FC = () => {
  return (
    <Header>
      <Title>Low-Code System</Title>
    </Header>
  )
}

const Header = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  margin-bottom: 20px;
  width: 100%;
`
const Title = styled.h1`
  font-size: ${props => props.theme.fontSizes.xlarge};
  font-weight: ${props => props.theme.fontWeights.bold};
  width: 100%;
  text-align: center;
  margin-bottom: 20px;
  color: ${props => props.theme.colors.primary[1]};
`
