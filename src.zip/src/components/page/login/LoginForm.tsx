import React from 'react'
import styled from 'styled-components'
import { useLogin } from '../../../hooks/login'

export const LoginForm: React.FC = () => {
  const { handleChange, handleSubmit, state } = useLogin()
  return (
    <Form>
      <Input
        type="text"
        placeholder="Email"
        name="email"
        required
        onChange={handleChange}
      />
      <Input
        type="password"
        placeholder="Password"
        name="password"
        required
        onChange={handleChange}
      />
      {state.error && <Error>{state.error}</Error>}
      <Button onClick={handleSubmit}>Login</Button>
      <SignUp>
        {"Don't have an account?"} <Link href="/register">Sign up</Link>
      </SignUp>
    </Form>
  )
}

const Form = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  max-width: 400px;
  margin: 0 auto;
`
const Input = styled.input`
  width: 100%;
  height: 40px;
  border-radius: ${props => props.theme.radii.medium};
  border: 1px solid ${props => props.theme.colors.light};
  padding: 0 ${props => props.theme.spacings.medium};
  margin-bottom: ${props => props.theme.spacings.medium};
`
const Button = styled.button`
  width: 100%;
  height: 40px;
  border-radius: ${props => props.theme.radii.medium};
  border: 1px solid ${props => props.theme.colors.primary[1]};
  background-color: ${props => props.theme.colors.primary[1]};
  color: ${props => props.theme.colors.light};
  font-size: ${props => props.theme.fontSizes.medium};
  font-weight: ${props => props.theme.fontWeights.bold};
  cursor: pointer;
  transition: all ${props => props.theme.transitions.small} ease-in-out;
  &:hover {
    background-color: ${props => props.theme.colors.primary[0]};
    border: 1px solid ${props => props.theme.colors.primary[0]};
  }
`
const SignUp = styled.div`
  font-size: ${props => props.theme.fontSizes.small};
  font-weight: ${props => props.theme.fontWeights.bold};
  color: ${props => props.theme.colors.light};
  margin-top: ${props => props.theme.spacings.medium};
  text-align: center;
`
const Link = styled.a`
  color: ${props => props.theme.colors.primary[2]};
  text-decoration: none;
  cursor: pointer;
  &:hover {
    color: ${props => props.theme.colors.primary[0]};
  }
`
const Error = styled.div`
  font-size: ${props => props.theme.fontSizes.small};
  font-weight: ${props => props.theme.fontWeights.bold};
  color: ${props => props.theme.colors.error};
  margin-top: ${props => props.theme.spacings.medium};
  text-align: center;
`
