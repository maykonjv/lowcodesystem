import React from 'react'

export const Header = () => {
  return (
    <>
      <h1>Header</h1>
    </>
  )
}
