import React from 'react'

export const Footer: React.FC = () => {
  return (
    <>
      <h1>Footer</h1>
    </>
  )
}
