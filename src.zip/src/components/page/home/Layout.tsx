import React from 'react'
import Nav from './Content'
import Sidebar from './sidebar'

function Layout(props) {
  return (
    <div>
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <div style={{ maxWidth: '800px' }}>
          <Nav />
          {props.children}
        </div>
      </div>
    </div>
  )
}

export default Layout
