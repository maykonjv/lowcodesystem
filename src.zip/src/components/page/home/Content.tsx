import React from 'react'

function Nav(props) {
  return (
    <div>
      <h2>{"I'm a nav"}</h2>
      <p>{"Ignore me. I'm not important. I'm cool, though."}</p>
    </div>
  )
}

export default Nav
