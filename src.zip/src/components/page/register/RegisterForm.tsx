import React from 'react'
import styled from 'styled-components'
import { useRegister } from '../../../hooks/register'
import { Button } from '../../button/button'

export const RegisterForm: React.FC = () => {
  const { handleChange, handleSubmit, state } = useRegister()
  return (
    <Form>
      <Input
        type="text"
        placeholder="Name"
        name="name"
        required
        onChange={handleChange}
      />
      <Input
        type="email"
        placeholder="Email"
        name="email"
        required
        onChange={handleChange}
      />
      <Input
        type="password"
        placeholder="Password"
        name="password"
        required
        onChange={handleChange}
      />
      <Input
        type="password"
        placeholder="Confirm Password"
        name="confirmPassword"
        required
        onChange={handleChange}
      />
      {state.error && <Error>{state.error}</Error>}
      <Button isLoading={state.loading} onPress={handleSubmit}>
        Register
      </Button>
      <SignIn>
        {'Already have an account?'} <Link href="/">Sign in</Link>
      </SignIn>
    </Form>
  )
}

const Form = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  max-width: 400px;
  margin: 0 auto;
`
const Input = styled.input`
  width: 100%;
  height: 40px;
  border-radius: ${props => props.theme.radii.medium};
  border: 1px solid ${props => props.theme.colors.light};
  padding: 0 ${props => props.theme.spacings.medium};
  margin-bottom: ${props => props.theme.spacings.medium};
`
const SignIn = styled.div`
  font-size: ${props => props.theme.fontSizes.small};
  font-weight: ${props => props.theme.fontWeights.bold};
  color: ${props => props.theme.colors.light};
  margin-top: ${props => props.theme.spacings.medium};
  text-align: center;
`
const Link = styled.a`
  color: ${props => props.theme.colors.primary[2]};
  text-decoration: none;
  cursor: pointer;
  &:hover {
    color: ${props => props.theme.colors.primary[0]};
  }
`
const Error = styled.div`
  font-size: ${props => props.theme.fontSizes.small};
  font-weight: ${props => props.theme.fontWeights.bold};
  color: ${props => props.theme.colors.error};
  margin-top: ${props => props.theme.spacings.medium};
  text-align: center;
`
